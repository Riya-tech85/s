<?php

namespace App\Controller;

use App\Entity\Users;
use App\Service\servicecall;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\RedirectResponse;

class DefaultController extends AbstractController
{
    /**
     * @Route("/default", name="app_default")
     */
    public function index(): Response
    {
        $msg = "";
        return $this->render('default/form.html.twig', [
            'controller_name' => 'DefaultController',
            'msg' => $msg,
        ]);
    }

    /**
     * @Route("/serviceid/{id}", name="service" ,methods={"GET"})
     */
    public function fun(int $id,servicecall $obj){
        echo $id;
        // $service = new servicecall;
        $pp = $obj->func($id);
        // dd($pp);
        // die();
        return $this->render('default/showdata.html.twig', [
            'controller_name' => 'DefaultController',
            'array' => $pp,
        ]);
    }

    /**
     * @Route("/db", name="savedata", methods="POST")
     */
    public function savedata(Request $request){
        $name=$request->request->get("name");
        $phone = $request->request->get("phone");
        $address = $request->request->get("address");
        $image = $request->request->get("image");
        // $folder = move("../../public/image".$image);

        $user_obj = new Users();
        $user_obj->setName($name);
        $user_obj->setPhone($phone);
        $user_obj->setAddress($address);
        $user_obj->setImage($image);
        
        $entitymanager = $this->getDoctrine()->getmanager();
        $p = $entitymanager->getRepository(Users::class)->findOneBy(2);
        $entitymanager->persist($user_obj);
        $entitymanager->flush();
        $msg = "data save";

         return $this->render('default/showdata.html.twig', [
            'controller_name' => 'DefaultController',
            'msg' => $msg,
        ]);
    }

    /**
     * @Route("/db1", name="savedata1", methods="GET")
     */
    public function find(Request $request){

        $entitymanager = $this->getDoctrine()->getmanager();
        $p = $entitymanager->getRepository(Users::class)->findOneById(2);
        // $entitymanager->persist($p);
        $entitymanager->flush();
        dd($p);
    }
    /**
     * @Route("/api/posts/{slug}", methods={"GET","HEAD"}, defaults={"slug":1 ,"title":"hello world!"})
     */
    public function show(int $slug, string $title)
    {
        dd($slug);
        dd($title);
    }

    /**
     * @Route("/api/posts/{id}", methods={"GET"})
     */
    public function edit(string $id): Response
    {
        dd($id);
    }

    /**
     * @Route(
     *     "/articles/{_locale}/search.{_format}",
     *     locale="en",
     *     format="html",
     *     requirements={
     *         "_locale": "en|fr",
     *         "_format": "html|xml",
     *     }
     * )
     */
    public function search(): Response
    {
        dd('hey');
    }

    /**
     * @Route("/share/{token}", name="share", requirements={"token"=".+"})
     */
    public function share($token): Response
    {
        dd('hhi');
    }
}
